package org.alexdev.havana.dao.mysql;

import org.alexdev.havana.dao.Storage;
import org.alexdev.havana.game.song.Song;
import org.alexdev.havana.game.song.SongPlaylist;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SongMachineDao {

    /**
     * Get the song list for this machine.
     *
     * @param itemId the item id for this machine
     * @return the list of songs
     */
    public static List<Song> getSongList(long itemId) {
        List<Song> songs = new ArrayList<>();

        Connection sqlConnection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            sqlConnection = Storage.getStorage().getConnection();
            preparedStatement = Storage.getStorage().prepare("SELECT * FROM soundmachine_songs WHERE item_id = ?", sqlConnection);
            preparedStatement.setLong(1, itemId);
            resultSet = preparedStatement.executeQuery();

            // (int id, String title, int itemId, int length, String data, boolean isBurnt)
            while (resultSet.next()) {
                songs.add(new Song(resultSet.getInt("id"), resultSet.getString("title"), itemId, resultSet.getInt("user_id"),
                        resultSet.getInt("length"), resultSet.getString("data"), resultSet.getBoolean("burnt")));
            }

        } catch (Exception e) {
            Storage.logError(e);
        } finally {
            Storage.closeSilently(resultSet);
            Storage.closeSilently(preparedStatement);
            Storage.closeSilently(sqlConnection);
        }

        return songs;
    }

    public static Song getSong(int songId) {
        Song song = null;

        Connection sqlConnection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            sqlConnection = Storage.getStorage().getConnection();
            preparedStatement = Storage.getStorage().prepare("SELECT * FROM soundmachine_songs WHERE id = ?", sqlConnection);
            preparedStatement.setInt(1, songId);
            resultSet = preparedStatement.executeQuery();

            // (int id, String title, int itemId, int length, String data, boolean isBurnt)
            if (resultSet.next()) {
                song = new Song(resultSet.getInt("id"), resultSet.getString("title"), resultSet.getLong("item_id"), resultSet.getInt("user_id"),
                        resultSet.getInt("length"), resultSet.getString("data"), resultSet.getBoolean("burnt"));
            }

        } catch (Exception e) {
            Storage.logError(e);
        } finally {
            Storage.closeSilently(resultSet);
            Storage.closeSilently(preparedStatement);
            Storage.closeSilently(sqlConnection);
        }

        return song;
    }

    public static List<SongPlaylist> getSongPlaylist(long itemId) {
        List<SongPlaylist> songs = new ArrayList<>();

        Connection sqlConnection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            sqlConnection = Storage.getStorage().getConnection();
            preparedStatement = Storage.getStorage().prepare("SELECT * FROM soundmachine_playlists WHERE item_id = ?", sqlConnection);
            preparedStatement.setLong(1, itemId);
            resultSet = preparedStatement.executeQuery();

            // (int id, String title, int itemId, int length, String data, boolean isBurnt)
            while (resultSet.next()) {
                songs.add(new SongPlaylist(itemId, getSong(resultSet.getInt("song_id")), resultSet.getInt("slot_id")));
            }

        } catch (Exception e) {
            Storage.logError(e);
        } finally {
            Storage.closeSilently(resultSet);
            Storage.closeSilently(preparedStatement);
            Storage.closeSilently(sqlConnection);
        }

        return songs;
    }

    public static void addPlaylist(long itemId, int songId, int slotId) throws SQLException {
        Connection sqlConnection = null;
        PreparedStatement preparedStatement = null;

        try {
            sqlConnection = Storage.getStorage().getConnection();
            preparedStatement = Storage.getStorage().prepare("INSERT INTO soundmachine_playlists (item_id, song_id, slot_id) VALUES (?, ?, ?)", sqlConnection);
            preparedStatement.setLong(1, itemId);
            preparedStatement.setInt(2, songId);
            preparedStatement.setInt(3, slotId);
            preparedStatement.execute();
        } catch (Exception e) {
            Storage.logError(e);
            throw e;
        } finally {
            Storage.closeSilently(preparedStatement);
            Storage.closeSilently(sqlConnection);
        }
    }

    public static void removePlaylistSong(int songId, long itemId) throws SQLException {
        Connection sqlConnection = null;
        PreparedStatement preparedStatement = null;

        try {
            sqlConnection = Storage.getStorage().getConnection();
            preparedStatement = Storage.getStorage().prepare("DELETE FROM soundmachine_playlists WHERE song_id = ? AND item_id = ? LIMIT 1", sqlConnection);
            preparedStatement.setInt(1, songId);
            preparedStatement.setLong(2, itemId);
            preparedStatement.execute();
        } catch (Exception e) {
            Storage.logError(e);
            throw e;
        } finally {
            Storage.closeSilently(preparedStatement);
            Storage.closeSilently(sqlConnection);
        }
    }

    public static void deleteSong(int songId) throws SQLException {
        Connection sqlConnection = null;
        PreparedStatement preparedStatement = null;

        try {
            sqlConnection = Storage.getStorage().getConnection();

            // Don't actually delete, just make it invisible, this is because some burned disks might use it.
            preparedStatement = Storage.getStorage().prepare("UPDATE soundmachine_songs SET item_id = -1 WHERE id = ?", sqlConnection);
            preparedStatement.setInt(1, songId);
            preparedStatement.execute();

        } catch (Exception e) {
            Storage.logError(e);
            throw e;
        } finally {
            Storage.closeSilently(preparedStatement);
            Storage.closeSilently(sqlConnection);
        }
    }

    public static void clearPlaylist(long itemId) throws SQLException {
        Connection sqlConnection = null;
        PreparedStatement preparedStatement = null;

        try {
            sqlConnection = Storage.getStorage().getConnection();
            preparedStatement = Storage.getStorage().prepare("DELETE FROM soundmachine_playlists WHERE item_id = ?", sqlConnection);
            preparedStatement.setLong(1, itemId);
            preparedStatement.execute();
        } catch (Exception e) {
            Storage.logError(e);
            throw e;
        } finally {
            Storage.closeSilently(preparedStatement);
            Storage.closeSilently(sqlConnection);
        }
    }


    public static void addSong(int userId, long soundMachineId, String title, int length, String data) throws SQLException {
        Connection sqlConnection = null;
        PreparedStatement preparedStatement = null;

        try {
            sqlConnection = Storage.getStorage().getConnection();
            preparedStatement = Storage.getStorage().prepare("INSERT INTO soundmachine_songs (user_id, item_id, title, length, data) VALUES (?, ?, ?, ?, ?)", sqlConnection);
            preparedStatement.setInt(1, userId);
            preparedStatement.setLong(2, soundMachineId);
            preparedStatement.setString(3, title);
            preparedStatement.setInt(4, length);
            preparedStatement.setString(5, data);
            preparedStatement.execute();
        } catch (Exception e) {
            Storage.logError(e);
            throw e;
        } finally {
            Storage.closeSilently(preparedStatement);
            Storage.closeSilently(sqlConnection);
        }
    }

    public static void saveSong(int songId, String title, int length, String data) throws SQLException {
        Connection sqlConnection = null;
        PreparedStatement preparedStatement = null;

        try {
            sqlConnection = Storage.getStorage().getConnection();
            preparedStatement = Storage.getStorage().prepare("UPDATE soundmachine_songs SET title = ?, length = ?, data = ? WHERE id = ?", sqlConnection);
            preparedStatement.setString(1, title);
            preparedStatement.setInt(2, length);
            preparedStatement.setString(3, data);
            preparedStatement.setInt(4, songId);
            preparedStatement.execute();
        } catch (Exception e) {
            Storage.logError(e);
            throw e;
        } finally {
            Storage.closeSilently(preparedStatement);
            Storage.closeSilently(sqlConnection);
        }
    }

    public static Map<Integer, Integer> getTracks(long soundMachineId) {
        Map<Integer, Integer> tracks = new HashMap<>();

        Connection sqlConnection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            sqlConnection = Storage.getStorage().getConnection();
            preparedStatement = Storage.getStorage().prepare("SELECT track_id, slot_id FROM soundmachine_tracks WHERE soundmachine_id = ?", sqlConnection);
            preparedStatement.setLong(1, soundMachineId);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                tracks.put(resultSet.getInt("slot_id"), resultSet.getInt("track_id"));
            }

        } catch (Exception e) {
            Storage.logError(e);
        } finally {
            Storage.closeSilently(resultSet);
            Storage.closeSilently(preparedStatement);
            Storage.closeSilently(sqlConnection);
        }

        return tracks;
    }

    public static void addTrack(long soundMachineId, int trackId, int slotId) throws SQLException {
        Connection sqlConnection = null;
        PreparedStatement preparedStatement = null;

        try {
            sqlConnection = Storage.getStorage().getConnection();
            preparedStatement = Storage.getStorage().prepare("INSERT INTO soundmachine_tracks (soundmachine_id, track_id, slot_id) VALUES (?, ?, ?)", sqlConnection);
            preparedStatement.setLong(1, soundMachineId);
            preparedStatement.setInt(2, trackId);
            preparedStatement.setInt(3, slotId);
            preparedStatement.execute();
        } catch (Exception e) {
            Storage.logError(e);
            throw e;
        } finally {
            Storage.closeSilently(preparedStatement);
            Storage.closeSilently(sqlConnection);
        }
    }

    public static void removeTrack(long soundMachineId, int slotId) throws SQLException {
        Connection sqlConnection = null;
        PreparedStatement preparedStatement = null;

        try {
            sqlConnection = Storage.getStorage().getConnection();
            preparedStatement = Storage.getStorage().prepare("DELETE FROM soundmachine_tracks WHERE soundmachine_id = ? AND slot_id = ?", sqlConnection);
            preparedStatement.setLong(1, soundMachineId);
            preparedStatement.setInt(2, slotId);
            preparedStatement.execute();
        } catch (Exception e) {
            Storage.logError(e);
            throw e;
        } finally {
            Storage.closeSilently(preparedStatement);
            Storage.closeSilently(sqlConnection);
        }
    }

    public static List<Song> getSongUserList(int userId) {
        List<Song> songs = new ArrayList<>();

        Connection sqlConnection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            sqlConnection = Storage.getStorage().getConnection();
            preparedStatement = Storage.getStorage().prepare("SELECT * FROM soundmachine_songs WHERE user_id = ?", sqlConnection);
            preparedStatement.setLong(1, userId);
            resultSet = preparedStatement.executeQuery();

            // (int id, String title, int itemId, int length, String data, boolean isBurnt)
            while (resultSet.next()) {
                songs.add(new Song(resultSet.getInt("id"), resultSet.getString("title"), resultSet.getInt("item_id"), resultSet.getInt("user_id"),
                        resultSet.getInt("length"), resultSet.getString("data"), resultSet.getBoolean("burnt")));
            }

        } catch (Exception e) {
            Storage.logError(e);
        } finally {
            Storage.closeSilently(resultSet);
            Storage.closeSilently(preparedStatement);
            Storage.closeSilently(sqlConnection);
        }

        return songs;
    }
}
