package org.alexdev.havana.game.alerts;

public enum AlertType {
    HC_EXPIRED,
    PRESENT,
    TUTOR_SCORE,
    CREDIT_DONATION
}
