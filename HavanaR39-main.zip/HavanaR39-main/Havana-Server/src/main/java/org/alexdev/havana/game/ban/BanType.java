package org.alexdev.havana.game.ban;

public enum BanType {
    USER_ID,
    MACHINE_ID,
    IP_ADDRESS;
}
