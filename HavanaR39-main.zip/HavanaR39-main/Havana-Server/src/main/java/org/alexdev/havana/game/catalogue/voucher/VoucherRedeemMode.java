package org.alexdev.havana.game.catalogue.voucher;

public enum VoucherRedeemMode {
    WEBSITE,
    IN_GAME
}