package org.alexdev.havana.game.catalogue.voucher;

public enum VoucherRedeemStatus {
    SUCCESS,
    FAILURE,
    FAILURE_NEW_ACCOUNT;
}
