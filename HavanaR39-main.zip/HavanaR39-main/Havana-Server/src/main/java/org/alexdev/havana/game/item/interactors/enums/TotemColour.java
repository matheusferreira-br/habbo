package org.alexdev.havana.game.item.interactors.enums;

public enum TotemColour {
    NONE,
    RED,
    YELLOW,
    BLUE
}
