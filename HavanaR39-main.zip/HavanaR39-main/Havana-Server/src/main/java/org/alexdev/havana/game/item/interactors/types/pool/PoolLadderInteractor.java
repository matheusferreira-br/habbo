package org.alexdev.havana.game.item.interactors.types.pool;

import org.alexdev.havana.game.entity.Entity;
import org.alexdev.havana.game.entity.EntityType;
import org.alexdev.havana.game.item.Item;
import org.alexdev.havana.game.room.entities.RoomEntity;
import org.alexdev.havana.game.room.enums.StatusType;
import org.alexdev.havana.game.triggers.GenericTrigger;
import org.alexdev.havana.game.pathfinder.Position;
import org.alexdev.havana.game.room.handlers.PoolHandler;
import org.alexdev.havana.messages.types.MessageComposer;
import org.alexdev.havana.server.netty.streams.NettyResponse;

public class PoolLadderInteractor extends GenericTrigger {
    /*@Override
    public void onEntityLeave(Entity entity, RoomEntity roomEntity, Item item, Position oldPosition) {
        this.onEntityStep(entity, roomEntity, item, oldPosition);

    }*/

    @Override
    public void onEntityStep(Entity entity, RoomEntity roomEntity, Item item, Position oldPosition) {
        if (entity.getType() != EntityType.PLAYER) {
            return;
        }

        if (item.getTeleportTo() == null) {
            return;
        }

        if (item.getDefinition().getSprite().equals("poolEnter")) {
            if (roomEntity.containsStatus(StatusType.SWIM)) {
                return;
            }

            roomEntity.setStatus(StatusType.SWIM, "");
        }

        if (item.getDefinition().getSprite().equals("poolExit")) {
            if (!roomEntity.containsStatus(StatusType.SWIM)) {
                return;
            }

            roomEntity.removeStatus(StatusType.SWIM);
        }

        roomEntity.stopWalking();

        //roomEntity.setWalkingAllowed(false);

        roomEntity.warp(item.getTeleportTo(), true, false);

        if (item.getSwimTo() != null) {
            roomEntity.setEnableWalkingOnStop(true);
            roomEntity.walkTo(item.getSwimTo().getX(), item.getSwimTo().getY());
        }

        item.showProgram(null);

       /* if (item.getRoom().getModel().equals("md_a")) {
            item.showProgram(null);
        } else {
         */   // handle_pool_stair_splash
            /*roomEntity.getRoom().send(new MessageComposer() {
                @Override
                public void compose(NettyResponse response) {
                    response.writeInt(0);
                }

                @Override
                public short getHeader() {
                    return 505;
                }
            });*/
       //}

        // Don't handle step event from RoomUser when changing paths
        //if (customArgs.length > 0) {
        //    return;
        //}

        /*

        Position warp = null;
        Position goal = null;

        if (item.getPosition().getX() == 20 && item.getPosition().getY() == 28) {
            warp = new Position(21, 28);
            goal = new Position(22, 28);
        }

        if (item.getPosition().getX() == 17 && item.getPosition().getY() == 21) {
            warp = new Position(16, 22);
            goal = new Position(16, 23);
        }

        if (item.getPosition().getX() == 31 && item.getPosition().getY() == 10) {
            warp = new Position(30, 11);
            goal = new Position(30, 12);
        }

        if ((item.getPosition().getX() == 11 && item.getPosition().getY() == 11) ||
                item.getPosition().getX() == 11 && item.getPosition().getY() == 10) {
            warp = new Position(12, 11);
            goal = new Position(13, 12);
        }
*/

        //if (warp != null) {
        //PoolHandler.warpSwim(item, entity, warp, goal, false);
        //}
    }
}
