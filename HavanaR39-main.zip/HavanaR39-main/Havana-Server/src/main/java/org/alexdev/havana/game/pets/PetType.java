package org.alexdev.havana.game.pets;

public enum PetType {
    DOG,
    CAT,
    CROC;
}
