package org.alexdev.havana.game.room.enums;

public enum DrinkType {
    DRINK,
    EAT,
    ITEM
}
