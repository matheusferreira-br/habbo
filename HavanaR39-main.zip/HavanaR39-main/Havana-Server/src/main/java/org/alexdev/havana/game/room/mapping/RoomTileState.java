package org.alexdev.havana.game.room.mapping;

public enum RoomTileState {
    OPEN,
    CLOSED
}